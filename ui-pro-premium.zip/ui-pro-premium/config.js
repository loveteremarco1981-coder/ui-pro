
// Inserisci qui il tuo endpoint GAS (/exec)
window.APP_CONFIG = {
  endpoint: "https://script.google.com/macros/s/AKfycbzWadQvolbaH1hIUFHjcSXsMcH9Z9iTss1Ty-uiVVKQ-TjMOBfajv3e262tnH_1Th0A/exec"
};
